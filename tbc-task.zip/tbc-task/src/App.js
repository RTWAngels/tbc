import "./css/App.css";

// Importing components (parts of the webpage)
import Navbar from "./components/Navbar";
import MainImage from "./assets/main-image.png";
import LearningCourses from "./components/LearningCourses";
import Intro from "./components/Intro";
import Partners from "./components/Partners";
import Footer from "./components/Footer";

function App() {
  // Changing the title of the page (basically <title> tag in <head> tag)
  document.title = "TBC x USAID";
  return (
    <div className="App">
      <div className="container">
        <Navbar />
        <div className="mainImageContainer">
          <div className="centeredTextImage">
            <p>TBC x USAID</p>
            <p>ტექნოლოგიური განათლებისთვის</p>
          </div>
          <img src={MainImage} width="100%" alt="main" />
        </div>
        <div>
          <Intro />
        </div>
        <div>
          <LearningCourses />
        </div>
        <div>
          <Partners />
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </div>
  );
}

export default App;
