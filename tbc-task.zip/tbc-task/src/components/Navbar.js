import "../css/Navbar.css"; // Import the CSS file for styling
import TBCLogo from "../assets/tbc-logo.png";

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbarContainer">
        <img src={TBCLogo} width="175vw" height="40vh" alt="logo" />
        <ul>
          <li>მთავარი</li>
          <li>TBC IT</li>
          <li className="navSelectedPage">TBC x USAID</li>
          <li>რისკები</li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
