import "../css/Footer.css";
import TBC from "../assets/TBC.png";

// Using react icons for facebook and youtube logo
import { FaFacebook, FaYoutube } from "react-icons/fa";

function Footer() {
  return (
    <div className="footerContainer">
      <div>
        <img src={TBC} className="text" width="100" height="40" />
        <br />
        <br />
        <p className="text">© 2023 ყველა უფლება დაცულია</p>
        <br />
        <br />
        <p className="termsAndCons">წესები და პირობები</p>
        <br />
      </div>
      <div>
        <div className="logoContainer">
          <FaFacebook color="grey" size={40} />
          <FaYoutube color="grey" size={40} />
        </div>
        <div>
          <br />
          <br />
          <button className="button">მოგვწერეთ</button>
        </div>
      </div>
    </div>
  );
}

export default Footer;
