import "../css/LearningCourses.css";

// Importing images from assets folder
import IOSDevImage from "../assets/courses/ios-dev.png";
import ReactDevImage from "../assets/courses/react-dev.png";
import IntroToPythonImage from "../assets/courses/intro-to-python.png";
import AdvancedPythonImage from "../assets/courses/advanced-python.png";
import AdvancedCybersecurityImage from "../assets/courses/advanced-cybersecurity.png";
import ToTImage from "../assets/courses/tot.png";
import BlockchainImage from "../assets/courses/blockchain.png";
import DevOpsImage from "../assets/courses/devops.png";
import InformationGovernanceImage from "../assets/courses/information-governance.png";

// Importing icon for right arrow for course detail button
import { FaArrowRight } from "react-icons/fa";

function LearningCourses() {
  return (
    <div className="learningCourses">
      <div className="learningCoursesTitleDiv">
        <p className="learningCoursesTitle">სასწავლო კურსები</p>
      </div>
      <div className="allCoursesContainer">
        <div className="layoutForBlocks">
          <div className="courseContainer">
            <img src={IOSDevImage} alt="course" />
            <div className="content">
              <div className="textTop">iOS Development</div>
              <br />
              <div className="textMiddle">რეგისტრაცია დასრულებულია</div>
            </div>
            <div>
              <div className="textBottom">
                <FaArrowRight />{" "}
                <a
                  className="textBottom"
                  href="https://www.tbcacademy.ge/usaid/ios-development"
                >
                  კურსის დეტალები{" "}
                </a>
              </div>
            </div>
          </div>
          <div className="courseContainer">
            <img src={ReactDevImage} alt="course" />
            <div className="content">
              <div className="textTop">React</div>
              <br />
              <div className="textMiddle">რეგისტრაცია დასრულებულია</div>
            </div>
            <div>
              <div className="textBottom">
                <FaArrowRight />{" "}
                <a
                  className="textBottom"
                  href="https://www.tbcacademy.ge/usaid/react"
                >
                  კურსის დეტალები{" "}
                </a>
              </div>
            </div>
          </div>
          <div className="courseContainer">
            <img src={IntroToPythonImage} alt="course" />
            <div className="content">
              <div className="textTop">Intro to Python</div>
              <br />
              <div className="textMiddle">რეგისტრაცია დასრულებულია</div>
            </div>
            <div>
              <div className="textBottom">
                <FaArrowRight />{" "}
                <a
                  className="textBottom"
                  href="https://www.tbcacademy.ge/usaid/python-basic"
                >
                  კურსის დეტალები{" "}
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="layoutForBlocks">
          <div className="courseContainer">
            <img src={AdvancedPythonImage} alt="course" />
            <div className="content">
              <div className="textTop">Advanced Python</div>
              <br />
              <div className="textMiddle">რეგისტრაცია დასრულებულია</div>
            </div>
            <div>
              <div className="textBottom">
                <FaArrowRight />{" "}
                <a
                  className="textBottom"
                  href="https://www.tbcacademy.ge/usaid/python-advance"
                >
                  კურსის დეტალები{" "}
                </a>
              </div>
            </div>
          </div>
          <div className="courseContainer">
            <img src={AdvancedCybersecurityImage} alt="course" />
            <div className="content">
              <div className="textTop">Advanced Cybersecurity Course</div>
              <br />
              <div className="textMiddle">რეგისტრაცია დასრულებულია</div>
            </div>
            <div>
              <div className="textBottom">
                <FaArrowRight />{" "}
                <a
                  className="textBottom"
                  href="https://www.tbcacademy.ge/usaid/information-security-advance"
                >
                  კურსის დეტალები{" "}
                </a>
              </div>
            </div>
          </div>
          <div className="courseContainer">
            <img src={ToTImage} alt="course" />
            <div className="content">
              <div className="textTop">ToT Training of Trainers</div>
              <br />
              <div className="textMiddle">რეგისტრაცია დასრულებულია</div>
            </div>
            <div>
              <div className="textBottom">
                <FaArrowRight />{" "}
                <a
                  className="textBottom"
                  href="https://www.tbcacademy.ge/usaid/training-of-trainers"
                >
                  კურსის დეტალები{" "}
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="layoutForBlocks">
          <div className="courseContainer">
            <img src={BlockchainImage} alt="course" />
            <div className="content">
              <div className="textTop">Blockchain</div>
              <br />
              <div className="textMiddle">რეგისტრაცია დასრულებულია</div>
            </div>
            <div>
              <div className="textBottom">
                <FaArrowRight />{" "}
                <a
                  className="textBottom"
                  href="https://www.tbcacademy.ge/usaid/blockchain"
                >
                  კურსის დეტალები{" "}
                </a>
              </div>
            </div>
          </div>
          <div className="courseContainer">
            <img src={DevOpsImage} alt="course" />
            <div className="content">
              <div className="textTop">DevOps</div>
              <br />
              <div className="textMiddle">რეგისტრაცია დასრულებულია</div>
            </div>
            <div>
              <div className="textBottom">
                <FaArrowRight />{" "}
                <a
                  className="textBottom"
                  href="https://www.tbcacademy.ge/usaid/devops"
                >
                  კურსის დეტალები{" "}
                </a>
              </div>
            </div>
          </div>
          <div className="courseContainer">
            <img src={InformationGovernanceImage} alt="course" />
            <div className="content">
              <div className="textTop">Information Security Governance</div>
              <br />
              <div className="textMiddle">რეგისტრაცია დასრულებულია</div>
            </div>
            <div>
              <div className="textBottom">
                <FaArrowRight />{" "}
                <a
                  className="textBottom"
                  href="https://www.tbcacademy.ge/usaid/information-security-basic"
                >
                  კურსის დეტალები{" "}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LearningCourses;
