import { useState } from "react";
import "../css/Partners.css";
import PartnersImage1 from "../assets/partners1.png";
import PartnersImage2 from "../assets/partners2.png";
import { FaAngleLeft, FaAngleRight } from "react-icons/fa";

export default function Partners() {
  // State management for partner images
  const [partnersImage, setPartnersImage] = useState(PartnersImage1);

  return (
    <div className="partnersContainer">
      <p className="partnersTitle">პროექტის პარტნიორები</p>
      <div className="partners">
        <div
          className="scrollButton"
          onClick={() => {
            setPartnersImage(PartnersImage1);
          }}
        >
          <FaAngleLeft />
        </div>
        <div>
          <img src={partnersImage} />
        </div>
        <div
          className="scrollButton"
          onClick={() => {
            setPartnersImage(PartnersImage2);
          }}
        >
          <FaAngleRight />
        </div>
      </div>
      <div className="scrollPage">{". . ."}</div>
    </div>
  );
}
