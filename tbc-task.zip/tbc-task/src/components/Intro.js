import "../css/Intro.css";

function Intro() {
  return (
    <div className="allIntroContainer">
      <div className="introTextContainer">
        <p className="introText">
          „ TBC x USAID - ტექნოლოგიური განათლებისთვის “ პროგრამა საინფორმაციო
          ტექნოლოგიებით დაინტერესებულ ადამიანებს გთავაზობთ სრულად დაფინანსებულ
          ონლაინ საგანმანათლებლო პრაქტიკულ კურსებს სხვადასხვა ICT მიმართულებით.
          წარმატებულ კურსდამთავრებულებს ეძლევათ შესაძლებლობა დასაქმდნენ თიბისისა
          და მის პარტნიორ კომპანიებში.
        </p>
      </div>
      <div className="learnMoreTextContainer">
        <a href="https://www.tbcacademy.ge/usaid-about" className="learnMoreText">გაიგე მეტი</a>
      </div>
    </div>
  );
}

export default Intro;
